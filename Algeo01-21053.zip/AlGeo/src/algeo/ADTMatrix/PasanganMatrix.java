package src.algeo.ADTMatrix;

public class PasanganMatrix {
    public Matrix m;
    public Matrix x;

    public PasanganMatrix(Matrix a, Matrix b){
        this.m = a;
        this.x = b;
    }
}
